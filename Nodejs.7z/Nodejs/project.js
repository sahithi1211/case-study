var express = require('express');
var http = require('http');
var cors = require('cors');
var parser=require('body-parser');
var fs=require('fs');
var MongoClient = require('mongodb').MongoClient
var url = "mongodb://localhost:27017/";
var exp = express();
exp.use(cors());
var jsonData = fs.readFileSync('./products.json')

jsondata = JSON.parse(jsonData);

exp.get("/rest/api/load",cors(),(req,res)=>{
    console.log('Load Invoked');
    res.send({msg:'Loads the Json file'});
});

exp.route('/rest/api/get',cors()).get((req,res)=>{
    console.log("Get Invoked");
     let data = fs.readFileSync('products.json');
    let product = JSON.parse(data);
    console.log(product);
    res.send(product);
});
exp.route('/rest/api/get/:Name').get((req,res)=>{
    res.send("Product is"+req.params['Name']);
    jsondata.map(obj=>{
        
       if( obj.Name ==  req.params['Name'] ){
           console.log(obj);
       }
    })
})
exp.route('/rest/api/update/:name').get((req,res)=>{
   res.send("product from id"+req.params['name']);
    jsondata.map(obj=>{
       if(obj.Name === req.params['name']){
           obj.Name="Chocolate";
           fs.writeFileSync('products.json',JSON.stringify(jsondata));
           
       }
    })
})
exp.use(parser.json());
exp.route('/rest/api/post',cors()).post((req,res)=>{
    console.log("Post Invoked");
    console.log(req.body);
      jsondata.push(req.body);
    //res.send(jsondata);
    fs.writeFileSync('products.json', JSON.stringify(jsondata));
}); 

exp.route('/rest/api/delete',cors()).post((req,res)=>{
    console.log("delete Invoked");
    var index=req.body;
    for(var i in jsondata)
    {
        if(i==index.id)
        {
            jsondata.splice(i,1);

        }
    }
    fs.writeFileSync('products.json', JSON.stringify(jsondata));
});

exp.listen(3001);
