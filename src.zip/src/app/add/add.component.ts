import { Component, OnInit } from '@angular/core';
import{ProductService} from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
id:number;
name:string;
price:number;
desc:string;
  constructor(private productservice:ProductService,private router: Router) { }

  ngOnInit() {
  }
add(){

this.productservice.postproduct(this.id,this.name,this.price,this.desc).subscribe((data:any)=>{

});
this.router.navigate(['./main']);
}
clearData(){
this.router.navigate(['./main']);
}
}

