import { Component, OnInit } from '@angular/core';
import {ProductService} from "../product.service";
import { Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {

 products = [];
  p:number=1;
id:any;
  constructor(private productservice: ProductService,private router: Router) { }

  ngOnInit() {
      this.productservice .getProducts()
      .subscribe(data => (this.products = data));
  }
  title = 'Product Application';

  addproduct(){
     this.router.navigate(['\add']);
  }
delete(id)
{
  
  var index=id+((this.p-1)*4);
  alert(index);
  alert("Are you sure you want to delete?");
  this.productservice.deleteProducts(index).subscribe(data => (this.products = data));
}
edit(){
  alert("Do you want to edit?");
}
}
