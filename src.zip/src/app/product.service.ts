import { Injectable } from '@angular/core';
import {Product} from './product';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private _urlGet: string = "http://127.0.0.1:3001/rest/api/get";

  constructor(private http:HttpClient) { }

    getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this._urlGet);
  }
     postproduct(eid:number,ename:string,eprice:number,edes:string):Observable<any>{


   return this.http.post('http://127.0.0.1:3001/rest/api/post',{
    id: eid,
        Name: ename,
        Description: edes,
        Price: eprice
    });
   }
   deleteProducts(eid:any):Observable<any>{
     console.log(eid);
   return this.http.post('http://127.0.0.1:3001/rest/api/delete',{
    id: eid
    });
   }
  
   }

